import streamlit as st
import pandas as pd
import joblib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import gaussian_kde


st.set_page_config(
    page_title="compositePML",
    page_icon="🎈",
    layout="wide",
    initial_sidebar_state="expanded",
    #theme="css_theme",
)


with st.sidebar:
    
    st.title('Welcome to our website!')
    choice=st.radio('',['Home Page','Molten salt properties','Predicting Usage','Performance Prediction'])
    st.divider()
    

    
if choice == 'Home Page':
    st.sidebar.info('You can learn the basic information of the webpage from the Home Page. If you want to make predictions, please read Usage carefully before making performance predictions. :pencil:')
    st.title('compositePML: performance & machine learning for composite materials')    
    st.subheader('A tool for predicting the phase transition performance of inorganic composite phase change materials')
    st.markdown('**Created by Fengqi Li, Tingli Liu and Xiangdong Zhang**')
    st.markdown('**Liaoning University**')
    st.divider()
    
    st.subheader('Introduction')
    st.write('Molten salt phase change materials are widely used in the field of energy storage, and Expanded Graphite(EG) can be added to enhance performance in order to enhance energy efficiency. In order to find the optimal ratio for the combination performance of multiple molten salts, we designed this application. It can predict the melting point, melting heat, and thermal conductivity of molten salt phase change materials and multi-component molten salt/EG composite materials during phase change. By adjusting the ratio based on the predicted results, composite materials with low melting point, high melting heat, and high thermal conductivity can be obtained. \n In addition, you can also learn about the physical, thermodynamic, and structural properties of lava through this application. To query, you can select :red[Predicting Usage] in the border bar.\n\n- Melting point: The temperature at which substances transition between solid and liquid states.\n- Heat of fusion: The heat absorbed by a unit mass of crystalline material to become a liquid substance at the same temperature at its melting point.\n- Thermal conductivity: A measure of the ability to conduct heat of a substance.')
    st.divider()
    
    st.subheader('Database Overview')
    st.write('\n- This dataset involves five types of molten salts, including nitrates, carbonates, sulfates, and halogens (mainly chloride salts), and covers the prediction of the performance of single, binary, and ternary composite molten salts. The supporting materials are mainly EG. We roughly divide the material types into five as shown in the following figure, which shows the ratios of various types of molten salts in existing composite materials and can be used as a reference.\n- The distribution of database performance is shown in the table, which shows that the numerical range for the three test performances is large, and the above molten salt types cover a wide range. The model predicts the reliability of composite materials.  ')
    col1, col2 = st.columns(2)
    data3=pd.read_excel('./binary.xlsx')
    fig=plt.figure(figsize=(15,8),dpi=300)
    plt.rcParams["font.sans-serif"]=["Times New Roman"]
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams["font.size"]=22
    fig.patch.set_facecolor('white')#设置背景颜色
    fig.patch.set_alpha(1)#设置透明度
    plot=plt.gca();#获得坐标轴的句柄
    plot.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    plot.spines['left'].set_linewidth(1.5);####设置左边坐标轴的粗细
    sns.despine()

    ax=sns.histplot(
        x="Molten salt category"
        ,y="Molten salt content(%)"
        ,data=data3
        ,bins=20
        ,cmap='OrRd'
    )

    #colorbar
    norm = plt.Normalize(data3['Molten salt content(%)'].min(), data3['Molten salt content(%)'].max())
    sm = plt.cm.ScalarMappable(cmap='OrRd', norm=norm)
    sm.set_array([])
    ax.figure.colorbar(sm)

    plt.xlabel("Molten salt category",fontsize=26)
    plt.ylabel("Molten salt content/%",fontsize=26)
    plt.title('Frequency of adding different types of molten salts in binary molten salts',fontsize=26)
    st.set_option('deprecation.showPyplotGlobalUse', False)
    col1.pyplot()
    
    data8=pd.read_excel('./ternary.xlsx')
    fig=plt.figure(figsize=(15,8),dpi=300)
    plt.rcParams["font.sans-serif"]=["Times New Roman"]
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams["font.size"]=22
    fig.patch.set_facecolor('white')#设置背景颜色
    fig.patch.set_alpha(1)#设置透明度
    plot=plt.gca();#获得坐标轴的句柄
    plot.spines['bottom'].set_linewidth(1.5);###设置底部坐标轴的粗细
    plot.spines['left'].set_linewidth(1.5);####设置左边坐标轴的粗细
    sns.despine()

    ax=sns.histplot(
        x="Molten salt category"
        ,y="Molten salt content(%)"
        ,data=data8
        ,bins=20
        ,cmap='OrRd'
    )

    #colorbar
    norm = plt.Normalize(data8['Molten salt content(%)'].min(), data8['Molten salt content(%)'].max())
    sm = plt.cm.ScalarMappable(cmap='OrRd', norm=norm)
    sm.set_array([])
    ax.figure.colorbar(sm)

    plt.xlabel("Molten salt category",fontsize=26)
    plt.ylabel("Molten salt content/%",fontsize=26)
    plt.title('Frequency of adding different types of molten salts in ternary molten salts',fontsize=26)
    st.set_option('deprecation.showPyplotGlobalUse', False)
    col2.pyplot()
    
    data_table = {
    ' ': ['Min', 'Median', 'Max', 'Mean'],
    'Melting plont/℃': [80, 294, 1680, 386],
    'Heat of fusion/(J·g-1)': [31, 150, 1041, 187],
    'Thermal conductivity/(W·m-1·K-1)':[0.16, 1.28, 21.89, 3.11]
                 }
    df = pd.DataFrame(data_table)


    st.write('##### Table  Database Overview.')
    st.table(df) 
    st.divider()
    
    st.subheader('Predictive Accuracy')
    st.write('By adjusting the model and comparing its stability, the final model was determined to have good predictive accuracy. The accuracy of the three performance models on the test set can reach :red[0.8 or above], with good generalization ability and can be used for practical prediction.')
    st.divider()
    
    
    col1, col2 = st.columns(2) 
    col1.subheader('Authors')
    col1.write('Please feel free to contact us with any issues, comments, or questions.')
    col1.markdown('##### Fengqi Li')
    col1.markdown('Email:')
    col1.markdown('##### Tingli Liu')
    col1.markdown('Email:')
    col1.markdown('##### Xiangdong Zhang')
    col1.markdown('Email:')
    col2.subheader('Note')
    col2.write('This application aims to predict the performance of :red[inorganic] phase change materials, but cannot predict organic materials. The input material should be :red[molten salt] rather than other materials.')
    st.divider()
    
    st.write('Developed and Maintained by Tingli Liu and Fengqi Li')

    
if choice == 'Molten salt properties':
    st.title('Molten salt properties') 
    st.divider()
    st.markdown('##### Query Description: Enter the desired molten salt in the search box and click the :green[Start Querying] button to obtain its :green[physical, thermodynamic, and structural properties].')
    input_value = st.text_input(
        ' **Please enter the molten salt you want to query.** '
        ,value='NaCl'
    )
    
    if st.button("Start Querying"):
        if input_value == 'NaCl':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.165 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 58.443 g/mol')
            st.markdown('##### 1.3 SMILES style\n [Na+].[Cl-]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 801 ℃')
            st.markdown('##### 2.2 Boiling point\n 1465 ℃')
            st.markdown('##### 2.3 Melting heat\n 482 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 2')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 3.97 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -1.884 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0.154 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 42.96 Å³')
            st.markdown('##### 3.8 Number of atoms\n 2')
            st.markdown('##### 3.9 Cationic radius\n 0.102 nm')
            st.markdown('##### 3.10 Anion radius\n 0.181 nm')
            st.markdown('##### 3.11 Cation valence state\n 1')
            st.divider()
            
        if input_value == 'MgSO4':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.66 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 120.366 g/mol')
            st.markdown('##### 1.3 SMILES style\n [O-]S(=O)(=O)[O-].[Mg+2]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 1124 ℃')
            st.markdown('##### 2.2 Boiling point\n 1150 ℃')
            st.markdown('##### 2.3 Melting heat\n 122 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 88.6 Å²')
            st.markdown('##### 3.2 Complexity\n 62.2')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 5.53 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -2.394 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0.005 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 270.85 Å³')
            st.markdown('##### 3.8 Number of atoms\n 24')
            st.markdown('##### 3.9 Cationic radius\n 0.0.072 nm')
            st.markdown('##### 3.10 Anion radius\n 0.28 nm')
            st.markdown('##### 3.11 Cation valence state\n 2')
            st.divider()
            
        if input_value == 'NaNO3':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.257 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 84.9974 g/mol')
            st.markdown('##### 1.3 SMILES style\n [N+](=O)([O-])[O-].[Na+]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 306.8 ℃')
            st.markdown('##### 2.2 Boiling point\n 380 ℃')
            st.markdown('##### 2.3 Melting heat\n 162.5 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 62.9 Å²')
            st.markdown('##### 3.2 Complexity\n 18.8')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 2.95 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -1.361 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 360.02 Å³')
            st.markdown('##### 3.8 Number of atoms\n 30')
            st.markdown('##### 3.9 Cationic radius\n 0.102 nm')
            st.markdown('##### 3.10 Anion radius\n 0.189 nm')
            st.markdown('##### 3.11 Cation valence state\n 1')
            st.divider()
            
        if input_value == 'KCl':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 1.98 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 74.555 g/mol')
            st.markdown('##### 1.3 SMILES style\n [Cl-].[K+]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 771 ℃')
            st.markdown('##### 2.2 Boiling point\n 1420 ℃')
            st.markdown('##### 2.3 Melting heat\n 353 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 2')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 4.8 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -2.098 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0.078 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 56.59 Å³')
            st.markdown('##### 3.8 Number of atoms\n 2')
            st.markdown('##### 3.9 Cationic radius\n 0.138 nm')
            st.markdown('##### 3.10 Anion radius\n 0.181 nm')
            st.markdown('##### 3.11 Cation valence state\n 1')
            st.divider()
            
        if input_value == 'CaSO4':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.96 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 136.14 g/mol')
            st.markdown('##### 1.3 SMILES style\n [O-]S(=O)(=O)[O-].[Ca+2]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 1460 ℃')
            st.markdown('##### 2.2 Boiling point\n 1460 ℃')
            st.markdown('##### 2.3 Melting heat\n 142 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 88.6 Å²')
            st.markdown('##### 3.2 Complexity\n 62.2')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 5.95 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -2.666 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 303.58 Å³')
            st.markdown('##### 3.8 Number of atoms\n 24')
            st.markdown('##### 3.9 Cationic radius\n 0.1 nm')
            st.markdown('##### 3.10 Anion radius\n 0.28 nm')
            st.markdown('##### 3.11 Cation valence state\n 2')
            st.divider()
            
        if input_value == 'KNO3':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.016 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 101.1032 g/mol')
            st.markdown('##### 1.3 SMILES style\n [N+](=O)([O-])[O-].[K+]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 337 ℃')
            st.markdown('##### 2.2 Boiling point\n 400 ℃')
            st.markdown('##### 2.3 Melting heat\n 99.64 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 62.9 Å²')
            st.markdown('##### 3.2 Complexity\n 18.8')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 2.94 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -1.42 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 306.25 Å³')
            st.markdown('##### 3.8 Number of atoms\n 20')
            st.markdown('##### 3.9 Cationic radius\n 0.138 nm')
            st.markdown('##### 3.10 Anion radius\n 0.189 nm')
            st.markdown('##### 3.11 Cation valence state\n 1')
            st.divider()
            
        if input_value == 'RbCl':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 2.8 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 120.921 g/mol')
            st.markdown('##### 1.3 SMILES style\n [Cl-].[Rb+]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 723 ℃')
            st.markdown('##### 2.2 Boiling point\n 1390 ℃')
            st.markdown('##### 2.3 Melting heat\n 197 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 2')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 2')
            st.markdown('##### 3.4 Band gap\n 4.84 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -2.245 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 289.78 Å³')
            st.markdown('##### 3.8 Number of atoms\n 8')
            st.markdown('##### 3.9 Cationic radius\n 0.152 nm')
            st.markdown('##### 3.10 Anion radius\n 0.181 nm')
            st.markdown('##### 3.11 Cation valence state\n 1')
            st.divider()
            
        if input_value == 'CaF2':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 3.18 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 78.075 g/mol')
            st.markdown('##### 1.3 SMILES style\n [F-].[F-].[Ca+2]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 1418 ℃')
            st.markdown('##### 2.2 Boiling point\n 2533 ℃')
            st.markdown('##### 2.3 Melting heat\n 381 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 0')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 3')
            st.markdown('##### 3.4 Band gap\n 7.47 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -4.189 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0.035 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 147.73 Å³')
            st.markdown('##### 3.8 Number of atoms\n 12')
            st.markdown('##### 3.9 Cationic radius\n 0.1 nm')
            st.markdown('##### 3.10 Anion radius\n 0.133 nm')
            st.markdown('##### 3.11 Cation valence state\n 2')
            st.divider()
            
        if input_value == 'CaBr2':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 3.353 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 199.89 g/mol')
            st.markdown('##### 1.3 SMILES style\n [Ca+2].[Br-].[Br-]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 742 ℃')
            st.markdown('##### 2.2 Boiling point\n 1815 ℃')
            st.markdown('##### 2.3 Melting heat\n 253 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 0')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 3')
            st.markdown('##### 3.4 Band gap\n 4.53 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -2.375 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 200.63 Å³')
            st.markdown('##### 3.8 Number of atoms\n 6')
            st.markdown('##### 3.9 Cationic radius\n 0.1 nm')
            st.markdown('##### 3.10 Anion radius\n 0.196 nm')
            st.markdown('##### 3.11 Cation valence state\n 2')
            st.divider()
            
        if input_value == 'CaI2':
            st.subheader('1  Physical property')
            st.markdown('##### 1.1 Density\n 3.956 g/cm3')
            st.markdown('##### 1.2 Molecular weight\n 293.887 g/mol')
            st.markdown('##### 1.3 SMILES style\n [Ca+2].[I-].[I-]')
            st.divider()
            
            st.subheader('2  Thermodynamic properties')
            st.markdown('##### 2.1 Melting point\n 783 ℃')
            st.markdown('##### 2.2 Boiling point\n 1100 ℃')
            st.markdown('##### 2.3 Melting heat\n 145 J/g')
            st.divider()
            
            st.subheader('3  Structure property ')
            st.markdown('##### 3.1 Topological polar surface area\n 0 Å²')
            st.markdown('##### 3.2 Complexity\n 0')
            st.markdown('##### 3.3 Covalently-bonded unit count\n 3')
            st.markdown('##### 3.4 Band gap\n 3.9 eV')
            st.markdown('##### 3.5 Predicted formation energy\n -1.928 eV/atom')
            st.markdown('##### 3.6 Energy above hull\n 0 eV/atom')
            st.markdown('##### 3.7 Crystal volume\n 128.07 Å³')
            st.markdown('##### 3.8 Number of atoms\n 3')
            st.markdown('##### 3.9 Cationic radius\n 0.1 nm')
            st.markdown('##### 3.10 Anion radius\n 0.22 nm')
            st.markdown('##### 3.11 Cation valence state\n 2')
            st.divider()
    pass   
       

if choice == 'Predicting Usage':
    st.sidebar.info('Please carefully review the usage instructions!')
    st.title('Usage')
    st.divider()
        
    st.markdown('#### 1. Select the :blue[composition] of phase change materials from the dropdown menu.If there is no desired molten salt in the menu, you need to search for the corresponding properties of the molten salt at the website provided in the sidebar and fill it in the number input box below.')
    st.image(
        'Usage 1.png'
        ,width=800
    )
    st.image(
        'Usage 2.png'
        ,width=800
    )
    st.markdown('#### 2. Select the :blue[content] of molten salt added on the slider.')
    st.image(
        'Usage 3.png'
        ,width=800
    )
    st.markdown('#### 3. If you :blue[manually input parameters] in the first step, please :blue[check] it; otherwise, the model will report an error.')
    st.image(
        'Usage 4.png'
        ,width=800
    )
    st.markdown('#### 4. Enter the :blue[parameters related to EG] and select the :blue[EG content].')
    st.image(
        'Usage 5.png'
        ,width=800
    )
    st.markdown('#### 5. Input :blue[process] parameters.')
    st.image(
        'Usage 6.png'
        ,width=800
    )
    
    st.markdown('#### 6. Click the :blue[Start Prediction] button.')
    st.image(
        'Usage 7.jpg'
        ,width=800
    )
      

    
    
if choice == 'Performance Prediction':
    import uuid
    import re
    def create_st_button(link_text, link_url, hover_color="#e78ac3", st_col=None):

        button_uuid = str(uuid.uuid4()).replace("-", "")
        button_id = re.sub("\d+", "", button_uuid)

        button_css = f"""
            <style>
            #{button_id} {{
                background-color: rgb(255, 255, 255);
                color: rgb(38, 39, 48);
                padding: 0.25em 0.38em;
                position: relative;
                text-decoration: none;
                border-radius: 4px;
                border-width: 1px;
                border-style: solid;
                border-color: rgb(230, 234, 241);
                border-image: initial;

            }}
            #{button_id}:hover {{
                border-color: {hover_color};
                color: {hover_color};
            }}
            #{button_id}:active {{
                box-shadow: none;
                background-color: {hover_color};
                color: white;
                }}
        </style> """

        html_str = f'<a href="{link_url}" target="_blank" id="{button_id}";>{link_text}</a><br></br>'

        if st_col is None:
            st.markdown(button_css + html_str, unsafe_allow_html=True)
        else:
            st_col.markdown(button_css + html_str, unsafe_allow_html=True)
    
    
    database_link_dict = {
        "PubChem": "https://pubchem.ncbi.nlm.nih.gov/",
        "Materials Project": "https://next-gen.materialsproject.org/",
        "wikipedia": "https://en.wikipedia.org/",
    }

    st.sidebar.markdown("## Molten salt performance-Related Links")
    for link_text, link_url in database_link_dict.items():
        create_st_button(link_text, link_url, st_col=st.sidebar)
        
        
    st.title('Performance Prediction')
    st.divider()
    
    st.markdown('### Phase change materials')
    st.markdown('#### _Composition_')
    col1, col2, col3 = st.columns(3)
    data=pd.read_excel('t.xlsx')
    option_1 = col1.selectbox(
        '##### :green[Molten salt 1]'
        ,data['Molten salt']
        ,index=3
        )
    option_2 = col2.selectbox(
        '##### :green[Molten salt 2]'
        ,data['Molten salt']
        ,index=5
        )
    option_3 = col3.selectbox(
        '##### :green[Molten salt 3]'
        ,data['Molten salt']
        )
        
    for i in data['Molten salt']:
        if option_1 == i:
            tpsa_1 = data[data['Molten salt'] == i].iloc[:,1].to_frame()
            tpsa_1 = tpsa_1.iloc[:,-1].values
            c_1 = data[data['Molten salt'] == i].iloc[:,2].to_frame()
            c_1 = c_1.iloc[:,-1].values
            cb_1 = data[data['Molten salt'] == i].iloc[:,3].to_frame()
            cb_1 = cb_1.iloc[:,-1].values
            bg_1 = data[data['Molten salt'] == i].iloc[:,4].to_frame()
            bg_1 = bg_1.iloc[:,-1].values
            pfe_1 = data[data['Molten salt'] == i].iloc[:,5].to_frame()
            pfe_1 = pfe_1.iloc[:,-1].values
            eah_1 = data[data['Molten salt'] == i].iloc[:,6].to_frame()
            eah_1 = eah_1.iloc[:,-1].values
            cv_1 = data[data['Molten salt'] == i].iloc[:,7].to_frame()
            cv_1 = cv_1.iloc[:,-1].values
            noa_1 = data[data['Molten salt'] == i].iloc[:,8].to_frame()
            noa_1 = noa_1.iloc[:,-1].values
            cr_1 = data[data['Molten salt'] == i].iloc[:,9].to_frame()
            cr_1 = cr_1.iloc[:,-1].values
            ar_1 = data[data['Molten salt'] == i].iloc[:,10].to_frame()
            ar_1 = ar_1.iloc[:,-1].values
            mp_1 = data[data['Molten salt'] == i].iloc[:,11].to_frame()
            mp_1 = mp_1.iloc[:,-1].values
            bp_1 = data[data['Molten salt'] == i].iloc[:,12].to_frame()
            bp_1 = bp_1.iloc[:,-1].values
            d_1 = data[data['Molten salt'] == i].iloc[:,13].to_frame()
            d_1 = d_1.iloc[:,-1].values
            hof_1 = data[data['Molten salt'] == i].iloc[:,14].to_frame()
            hof_1 = hof_1.iloc[:,-1].values
            mw_1 = data[data['Molten salt'] == i].iloc[:,15].to_frame()
            mw_1 = mw_1.iloc[:,-1].values
            cvs_1 = data[data['Molten salt'] == i].iloc[:,16].to_frame()
            cvs_1 = cvs_1.iloc[:,-1].values
    
    for a in data['Molten salt']:
        if option_2 == a:
            tpsa_2 = data[data['Molten salt'] == i].iloc[:,1].to_frame()
            tpsa_2 = tpsa_2.iloc[:,-1].values
            c_2 = data[data['Molten salt'] == i].iloc[:,2].to_frame()
            c_2 = c_2.iloc[:,-1].values
            cb_2 = data[data['Molten salt'] == i].iloc[:,3].to_frame()
            cb_2 = cb_2.iloc[:,-1].values
            bg_2 = data[data['Molten salt'] == i].iloc[:,4].to_frame()
            bg_2 = bg_2.iloc[:,-1].values
            pfe_2 = data[data['Molten salt'] == i].iloc[:,5].to_frame()
            pfe_2 = pfe_2.iloc[:,-1].values
            eah_2 = data[data['Molten salt'] == i].iloc[:,6].to_frame()
            eah_2 = eah_2.iloc[:,-1].values
            cv_2 = data[data['Molten salt'] == i].iloc[:,7].to_frame()
            cv_2 = cv_2.iloc[:,-1].values
            noa_2 = data[data['Molten salt'] == i].iloc[:,8].to_frame()
            noa_2 = noa_2.iloc[:,-1].values
            cr_2 = data[data['Molten salt'] == i].iloc[:,9].to_frame()
            cr_2 = cr_2.iloc[:,-1].values
            ar_2 = data[data['Molten salt'] == i].iloc[:,10].to_frame()
            ar_2 = ar_2.iloc[:,-1].values
            mp_2 = data[data['Molten salt'] == i].iloc[:,11].to_frame()
            mp_2 = mp_2.iloc[:,-1].values
            bp_2 = data[data['Molten salt'] == i].iloc[:,12].to_frame()
            bp_2 = bp_2.iloc[:,-1].values
            d_2 = data[data['Molten salt'] == i].iloc[:,13].to_frame()
            d_2 = d_2.iloc[:,-1].values
            hof_2 = data[data['Molten salt'] == i].iloc[:,14].to_frame()
            hof_2 = hof_2.iloc[:,-1].values
            mw_2 = data[data['Molten salt'] == i].iloc[:,15].to_frame()
            mw_2 = mw_2.iloc[:,-1].values
            cvs_2 = data[data['Molten salt'] == i].iloc[:,16].to_frame()
            cvs_2 = cvs_2.iloc[:,-1].values
           
    for b in data['Molten salt']:
        if option_3 == b:
            tpsa_3 = data[data['Molten salt'] == i].iloc[:,1].to_frame()
            tpsa_3 = tpsa_3.iloc[:,-1].values
            c_3 = data[data['Molten salt'] == i].iloc[:,2].to_frame()
            c_3 = c_3.iloc[:,-1].values
            cb_3 = data[data['Molten salt'] == i].iloc[:,3].to_frame()
            cb_3 = cb_3.iloc[:,-1].values
            bg_3 = data[data['Molten salt'] == i].iloc[:,4].to_frame()
            bg_3 = bg_3.iloc[:,-1].values
            pfe_3 = data[data['Molten salt'] == i].iloc[:,5].to_frame()
            pfe_3 = pfe_3.iloc[:,-1].values
            eah_3 = data[data['Molten salt'] == i].iloc[:,6].to_frame()
            eah_3 = eah_3.iloc[:,-1].values
            cv_3 = data[data['Molten salt'] == i].iloc[:,7].to_frame()
            cv_3 = cv_3.iloc[:,-1].values
            noa_3 = data[data['Molten salt'] == i].iloc[:,8].to_frame()
            noa_3 = noa_3.iloc[:,-1].values
            cr_3 = data[data['Molten salt'] == i].iloc[:,9].to_frame()
            cr_3 = cr_3.iloc[:,-1].values
            ar_3 = data[data['Molten salt'] == i].iloc[:,10].to_frame()
            ar_3 = ar_3.iloc[:,-1].values
            mp_3 = data[data['Molten salt'] == i].iloc[:,11].to_frame()
            mp_3 = mp_3.iloc[:,-1].values
            bp_3 = data[data['Molten salt'] == i].iloc[:,12].to_frame()
            bp_3 = bp_3.iloc[:,-1].values
            d_3 = data[data['Molten salt'] == i].iloc[:,13].to_frame()
            d_3 = d_3.iloc[:,-1].values
            hof_3 = data[data['Molten salt'] == i].iloc[:,14].to_frame()
            hof_3 = hof_3.iloc[:,-1].values
            mw_3 = data[data['Molten salt'] == i].iloc[:,15].to_frame()
            mw_3 = mw_3.iloc[:,-1].values
            cvs_3 = data[data['Molten salt'] == i].iloc[:,16].to_frame()
            cvs_3 = cvs_3.iloc[:,-1].values
            
    
    
    with st.expander("Please enter the properties of molten salt 1"):
        y1=st.number_input(
            'Topological polar surface area of molten salt 1(Å²)'
            ,min_value=0.0
            ,max_value=200.0              
            ,value=62.9
            ,step=10.0
        )
        y2=st.number_input(
            'Complexity of molten salt 1'
            ,min_value=0.0
            ,max_value=100.0
            ,value=18.8
            ,step=10.0
        )
        y3=st.number_input(
            'Covalently-bonded unit count of molten salt 1'
            ,min_value=0
            ,max_value=10
            ,value=2
            ,step=1
        )
        y4=st.number_input(
            'Band gap of molten salt 1(eV)'
            ,min_value=0.0
            ,max_value=10.0
            ,value=2.95
            ,step=0.1
        )
        y5=st.number_input(
            'Predicted formation energy of molten salt 1(eV/atom)'
            ,min_value=-10.0
            ,max_value=10.0
            ,value=-1.361
            ,step=1.0
        )
        y6=st.number_input(
            'Energy above hull of molten salt 1(eV/atom)'
            ,min_value=0.0
            ,max_value=5.0
            ,value=0.0
            ,step=1.0
        )
        y7=st.number_input(
            'Crystal volume of molten salt 1(Å³)'
            ,min_value=20.0
            ,max_value=1500.0
            ,value=360.02
            ,step=50.0
        )
        y8=st.number_input(
            'Number of atoms of molten salt 1'
            ,min_value=0
            ,max_value=100
            ,value=30
            ,step=10
        )
        y9=st.number_input(
            'Cationic radius of molten salt 1(nm)'
            ,min_value=0.0
            ,max_value=0.2
            ,value=0.102
            ,step=0.05
        )
        y10=st.number_input(
            'Anion radius of molten salt 1(nm)'
            ,min_value=0.0
            ,max_value=0.5
            ,value=0.189
            ,step=0.05
        )
        y11=st.number_input(
            'Melting point of molten salt 1(℃)'
            ,min_value=200.0
            ,max_value=1800.0
            ,value=306.8
            ,step=100.0
        )
        y12=st.number_input(
            'Boiling point of molten salt 1(℃)'
            ,min_value=100.0
            ,max_value=3000.0
            ,value=380.0
            ,step=100.0
        )
        y13=st.number_input(
            'Density of molten salt 1(g/cm3)'
            ,min_value=1.0
            ,max_value=10.0
            ,value=2.257
            ,step=1.0
        )
        y14=st.number_input(
            'Heat of fusion of molten salt 1(J/g)'
            ,min_value=30.0
            ,max_value=1200.0
            ,value=162.5
            ,step=100.0
        )
        y15=st.number_input(
            'Molecular weight of molten salt 1(g/mol)'
            ,min_value=20.0
            ,max_value=500.0
            ,value=84.9947
            ,step=100.0
        )
        y16=st.number_input(
            'Cation valence state of molten salt 1'
            ,min_value=1
            ,max_value=5
            ,value=1
            ,step=1
        )
    with st.expander("Please enter the properties of molten salt 2"):
        e1=st.number_input(
            'Topological polar surface area of molten salt 2(Å²)'
            ,min_value=0.0
            ,max_value=200.0
            ,value=62.9
            ,step=10.0
        )
        e2=st.number_input(
            'Complexity of molten salt 2'
            ,min_value=0.0
            ,max_value=100.0
            ,value=18.8
            ,step=10.0
        )
        e3=st.number_input(
            'Covalently-bonded unit count of molten salt 2'
            ,min_value=0
            ,max_value=10
            ,value=2
            ,step=1
        )
        e4=st.number_input(
            'Band gap of molten salt 2(eV)'
            ,min_value=0.0
            ,max_value=10.0
            ,value=2.94
            ,step=0.1
        )
        e5=st.number_input(
            'Predicted formation energy of molten salt 2(eV/atom)'
            ,min_value=-10.0
            ,max_value=10.0
            ,value=-1.42
            ,step=1.0
        )
        e6=st.number_input(
            'Energy above hull of molten salt 2(eV/atom)'
            ,min_value=0.0
            ,max_value=5.0
            ,value=0.0
            ,step=1.0
        )
        e7=st.number_input(
            'Crystal volume of molten salt 2(Å³)'
            ,min_value=20.0
            ,max_value=1500.0
            ,value=306.25
            ,step=50.0
        )
        e8=st.number_input(
            'Number of atoms of molten salt 2'
            ,min_value=0
            ,max_value=100
            ,value=20
            ,step=10
        )
        e9=st.number_input(
            'Cationic radius of molten salt 2(nm)'
            ,min_value=0.0
            ,max_value=0.2
            ,value=0.138
            ,step=0.05
        )
        e10=st.number_input(
            'Anion radius of molten salt 2(nm)'
            ,min_value=0.0
            ,max_value=0.5
            ,value=0.189
            ,step=0.05
        )
        e11=st.number_input(
            'Melting point of molten salt 2(℃)'
            ,min_value=200.0
            ,max_value=1800.0
            ,value=337.0
            ,step=100.0
        )
        e12=st.number_input(
            'Boiling point of molten salt 2(℃)'
            ,min_value=100.0
            ,max_value=3000.0
            ,value=400.0
            ,step=100.0
        )
        e13=st.number_input(
            'Density of molten salt 2(g/cm3)'
            ,min_value=1.0
            ,max_value=10.0
            ,value=2.016
            ,step=1.0
        )
        e14=st.number_input(
            'Heat of fusion of molten salt 2(J/g)'
            ,min_value=30.0
            ,max_value=1200.0
            ,value=99.64
            ,step=100.0
        )
        e15=st.number_input(
            'Molecular weight of molten salt 2(g/mol)'
            ,min_value=20.0
            ,max_value=500.0
            ,value=101.1032
            ,step=100.0
        )
        e16=st.number_input(
            'Cation valence state of molten salt 2'
            ,min_value=1
            ,max_value=5
            ,value=1
            ,step=1
        )
    with st.expander("Please enter the properties of molten salt 3"):
        s1=st.number_input(
            'Topological polar surface area of molten salt 3(Å²)'
            ,min_value=0.0
            ,max_value=200.0
            ,step=10.0
        )
        s2=st.number_input(
            'Complexity of molten salt 3'
            ,min_value=0.0
            ,max_value=100.0
            ,step=10.0
        )
        s3=st.number_input(
            'Covalently-bonded unit count of molten salt 3'
            ,min_value=0
            ,max_value=10
            ,step=1
        )
        s4=st.number_input(
            'Band gap of molten salt 3(eV)'
            ,min_value=0.0
            ,max_value=10.0
            ,step=0.1
        )
        s5=st.number_input(
            'Predicted formation energy of molten salt 3(eV/atom)'
            ,min_value=-10.0
            ,max_value=10.0
            ,step=1.0
        )
        s6=st.number_input(
            'Energy above hull of molten salt 3(eV/atom)'
            ,min_value=0.0
            ,max_value=5.0
            ,step=1.0
        )
        s7=st.number_input(
            'Crystal volume of molten salt 3(Å³)'
            ,min_value=20.0
            ,max_value=1500.0
            ,step=50.0
        )
        s8=st.number_input(
            'Number of atoms of molten salt 3'
            ,min_value=0
            ,max_value=100
            ,step=10
        )
        s9=st.number_input(
            'Cationic radius of molten salt 3(nm)'
            ,min_value=0.0
            ,max_value=0.2
            ,step=0.05
        )
        s10=st.number_input(
            'Anion radius of molten salt 3(nm)'
            ,min_value=0.0
            ,max_value=0.5
            ,step=0.05
        )
        s11=st.number_input(
            'Melting point of molten salt 3(℃)'
            ,min_value=200.0
            ,max_value=1800.0
            ,step=100.0
        )
        s12=st.number_input(
            'Boiling point of molten salt 3(℃)'
            ,min_value=100.0
            ,max_value=3000.0
            ,step=100.0
        )
        s13=st.number_input(
            'Density of molten salt 3(g/cm3)'
            ,min_value=1.0
            ,max_value=10.0
            ,step=1.0
        )
        s14=st.number_input(
            'Heat of fusion of molten salt 3(J/g)'
            ,min_value=30.0
            ,max_value=1200.0
            ,step=100.0
        )
        s15=st.number_input(
            'Molecular weight of molten salt 3(g/mol)'
            ,min_value=20.0
            ,max_value=500.0
            ,step=100.0)
        s16=st.number_input(
            'Cation valence state of molten salt 3'
            ,min_value=1
            ,max_value=5
            ,step=1
        )
   
    
    st.markdown('#### _Content_')
    col4, col5, col6 = st.columns(3)
    values_1 = col4.slider(
        'Molten salt 1 content'
        ,min_value=0.0
        ,max_value=1.0
        ,value=0.54
    )
    values_2 = col5.slider(
        'Molten salt 2 content'
        ,min_value=0.0
        ,max_value=1.0
        ,value=0.36
    )
    values_3 = col6.slider(
        'Molten salt 3 content'
        ,min_value=0.0
        ,max_value=1.0
    )
    
    yes = st.checkbox('**:red[If you manually input features, please check it, otherwise an error will be reported!]**')
    if yes:
        t1 = (values_1 * y1 + values_2 * e1 + values_3 * s1)/126
        t2 = (values_1 * y2 + values_2 * e2 + values_3 * s2)/62.2
        t3 = values_1 * (y3-2) + values_2 * (e3-2) + values_3 * (s3-2)
        t4 = (values_1 * y4 + values_2 * e4 + values_3 * s4)/7.47
        t5 = (values_1 * (y5+4.189) + values_2 * (e5+4.189) + values_3 * (s5+4.189))/6.451
        t6 = (values_1 * y6 + values_2 * e6 + values_3 * s6)/2.161
        t7 = (values_1 * (y7-38.29) + values_2 * (e7-38.29) + values_3 * (s7-38.29))/988.48
        t8 = (values_1 * (y8-2) + values_2 * (e8-2) + values_3 * (s8-2))/58
        t9 = (values_1 * (y9-0.072) + values_2 * (e9-0.072) + values_3 * (s9-0.072))/0.095
        t10 = (values_1 * (y10-0.133) + values_2 * (e10-0.133) + values_3 * (s10-0.133))/0.147
        t11 = (values_1 * (y11-253) + values_2 * (e11-253) + values_3 * (s11-253))/1427
        t12 = (values_1 * (y12-132) + values_2 * (e12-132) + values_3 * (s12-132))/2768
        t13 = (values_1 * (y13-1.98) + values_2 * (e13-1.98) + values_3 * (s13-1.98))/3.17
        t14 = (values_1 * (y14-31) + values_2 * (e14-31) + values_3 * (s14-31))/1010
        t15 = (values_1 * (y15-25.939) + values_2 * (e15-25.939) + values_3 * (s15-25.939))/365.197
        t16 = values_1 * (y16-1) + values_2 * (e16-1) + values_3 * (s16-1)
    else:
        t1 = (values_1 * tpsa_1 + values_2 * tpsa_2 + values_3 * tpsa_3)/126
        t2 = (values_1 * c_1 + values_2 * c_2 + values_3 * c_3)/62.2
        t3 = values_1 * (cb_1-2) + values_2 * (cb_2-2) + values_3 * (cb_3-2)
        t4 = (values_1 * bg_1 + values_2 * bg_2 + values_3 * bg_3)/7.47
        t5 = (values_1 * (pfe_1+4.189) + values_2 * (pfe_2+4.189) + values_3 * (pfe_3+4.189))/6.451
        t6 = (values_1 * eah_1 + values_2 * eah_2 + values_3 * eah_3)/2.161
        t7 = (values_1 * (cv_1-38.29) + values_2 * (cv_2-38.29) + values_3 * (cv_3-38.29))/988.48
        t8 = (values_1 * (noa_1-2) + values_2 * (noa_2-2) + values_3 * (noa_3-2))/58
        t9 = (values_1 * (cr_1-0.072) + values_2 * (cr_2-0.072) + values_3 * (cr_3-0.072))/0.095
        t10 = (values_1 * (ar_1-0.133) + values_2 * (ar_2-0.133) + values_3 * (ar_3-0.133))/0.147
        t11 = (values_1 * (mp_1-253) + values_2 * (mp_2-253) + values_3 * (mp_3-253))/1427
        t12 = (values_1 * (bp_1-132) + values_2 * (bp_2-132) + values_3 * (bp_3-132))/2768
        t13 = (values_1 * (d_1-1.98) + values_2 * (d_2-1.98) + values_3 * (d_3-1.98))/3.17
        t14 = (values_1 * (hof_1-31) + values_2 * (hof_2-31) + values_3 * (hof_3-31))/1010
        t15 = (values_1 * (mw_1-25.939) + values_2 * (mw_2-25.939) + values_3 * (mw_3-25.939))/365.197
        t16 = values_1 * (cvs_1-1) + values_2 * (cvs_2-1) + values_3 * (cv_3-1)
    
    
    st.markdown('### Support material')
    col7, col8, col9 = st.columns(3)
    nm = col7.number_input(
        '**Number of EG mesh**'
        ,min_value=10
        ,max_value=100
        ,value=80
        ,step=10
    )
    sa = col8.number_input(
        '**EG aperture(μm)**'
        ,min_value=150.0
        ,max_value=1500.0
        ,value=187.5
        ,step=100.0
    )
    er = col9.number_input(
        '**Expansion rate of EG(ml/g)**'
        ,min_value=100
        ,max_value=400
        ,value=300
        ,step=100
    )
    col10, col11 = st.columns(2)
    values_4 = col10.slider(
        'EG content'
        ,min_value=0.0
        ,max_value=1.0
        ,value=0.1
    )
    
    if values_1 + values_2 + values_3 + values_4 !=1:
        st.error('Please check if the input of molten salt and supporting material content is correct, and ensure that the sum is 1.0!')
    
    st.markdown('### Mixing process')
    T = st.number_input(
        '**Mixed heating temperature(℃)**'
        ,min_value=0
        ,max_value=800
        ,value=0
        ,step=100
    )
    t =st.number_input(
        '**Heating time(h)**'
        ,min_value=0.0
        ,max_value=24.0
        ,value=0.0
        ,step=5.0
    ) 
    st.divider()
    
    
    
    t17 = values_4
    t18 = (nm-32)/68
    t19 = (sa-187.5)/281.25
    t20 = (er-150)/150
    t21 = 0
    t22 = T/120
    t23 = (t-0.5)/23.5
          
    if st.button("Start Prediction"):
        ETR_1 = joblib.load("ETR_1.pkl")
        ETR_2 = joblib.load("ETR_2.pkl")
        ETR_3 = joblib.load("ETR_3.pkl")
        X = pd.DataFrame(
            [[t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23]]
            ,columns = ['Topological polar surface area of PCM(Å²)', 'Complexity of PCM', 'Covalently-bonded unit count of PCM','Band gap of PCM(eV)','Predicted formation energy of PCM(eV/atom)','Energy above hull of PCM(eV/atom)','Crystal volume of PCM(Å³)','Number of atoms of PCM','Cationic radius of PCM(nm)','Anion radius of PCM(nm)','Melting point of PCM(℃)','Boiling point of PCM(℃)','Density of PCM(g/cm3)','Heat of fusion of PCM(J/g)','Molecular weight of PCM(g/mol)','Cation valence state of PCM','Support material content(%)','Number of supporting material mesh','Support material aperture(μm)','Expansion rate of supporting materials(ml/g)','Support material-2 content(%)','Mixed heating temperature(℃)','Heating time(h)']
        )
        prediction_1 = np.exp(ETR_1.predict(X)[0])
        prediction_2 = np.exp(ETR_2.predict(X)[0])
        X1 = pd.DataFrame(
            [[t6,t17,t22,t23]]
            ,columns = ['Energy above hull of PCM(eV/atom)','Support material content(%)','Mixed heating temperature(℃)','Heating time(h)']
        )
        prediction_3 = ETR_3.predict(X1)[0]
        
        
        c1, c2 ,c3= st.columns(3)
        plt.rcParams["font.sans-serif"]=["SimHei"]
        plt.rcParams['axes.unicode_minus'] = False
        d1=pd.read_excel('t1.xlsx')
        sns.displot(
            d1
            ,x='mp'
            ,kind='kde'
            ,fill=True
        )
        plt.axvline(
            x=prediction_1
            ,color='r'
        )
        plt.xlabel('Melting point/℃')
        st.set_option('deprecation.showPyplotGlobalUse', False)
        c1.pyplot()
        
        d2=pd.read_excel('t2.xlsx')
        sns.displot(
            d2
            ,x='hf'
            ,kind='kde'
            ,fill=True
        )
        plt.axvline(
            x=prediction_2
            ,color='r'
        )
        plt.xlabel('Heat of fusion/J·g-1')
        st.set_option('deprecation.showPyplotGlobalUse', False)
        c2.pyplot()
       
        d3=pd.read_excel('t3.xlsx')
        sns.displot(
            d3
            ,x='tc'
            ,kind='kde'
            ,fill=True
        )
        plt.axvline(
            x=prediction_3
            ,color='r'
        )
        plt.xlabel('Thermal conductivity/W·m-1·K-1')
        st.set_option('deprecation.showPyplotGlobalUse', False)
        c3.pyplot()
        
        st.markdown(f"#### The predicted results are as follows:\n\n- Melting point: **:green[{'%.2f'%prediction_1}]** ℃\n- Heat of husion: **:green[{'%.2f'%prediction_2}]** J/g\n- Thermal conductivity: **:green[{'%.2f'%prediction_3}]** W/m·K")
        



    
    
